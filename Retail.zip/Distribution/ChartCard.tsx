import { Box, Paper, Typography, useTheme } from "@mui/material";
import { alpha, SxProps } from "@mui/system";
import { useState, useMemo } from "react";
import { useSelector } from "react-redux";
import { Line, Doughnut, Bar } from "react-chartjs-2";
import { getDarkModePreference, GlobalState } from "utils";
import { sub } from "date-fns";
import RangePicker from "components/RangePicker";

interface ChartCardProps {
  type: String;
  title: String;
  color: String;
  sx?: SxProps;
}

const ChartCard: React.FC<ChartCardProps> = ({
  type = "line",
  title = "Title",
  color = "#538ADC",
  sx = {},
}) => {
  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const theme = useTheme();

  const Chart: any = useMemo(() => {
    switch (type) {
      case "line":
        return Line;
      case "doughnut":
        return Doughnut;
      case "bar":
        return Bar;
    }
  }, [type]);

  const typeData = useMemo(() => {
    const labels = [
      "OKla",
      "Oct 2",
      "Oct 3",
      "Oct 4",
      "Oct 5",
      "Oct 6",
      "Oct 7",
      "Oct 8",
      "Oct 9",
      "Oct 10",
    ];
    const data = [50, 25, 20, 75, 50, 80, 70, 80, 15, 37];
    const defaultData = {
      labels,
      datasets: [
        {
          fill: true,
          data,
        },
      ],
    };

    switch (type) {
      case "doughnut":
        return {
          datasets: [
            {
              data: [3, 10],
              backgroundColor: [
                theme.customColors.greenSecondary,
                theme.customColors.blueSecondary,
              ],
              spacing: 1,
              hoverOffset: 0,
              borderWidth: 0,
              borderRadius: 50,
              cutout: "80%",
            },
          ],
          labels: ["Assigned Vendors", "Not Assigned"],
        };
      case "line": {
        const chartData = {
          ...defaultData,
          datasets: defaultData.datasets.map((oneData: any) => ({
            ...oneData,
            borderColor: color,
            borderWidth: 2,
            backgroundColor: alpha(
              theme.customColors.blueSecondary,
              isDarkMode ? 0.1 : 0.2
            ),
            tension: 0,
            pointRadius: 0,
            pointHoverRadius: 4,
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderWidth: 3,
          })),
        };
        return { ...chartData };
      }
      default: {
        const chartData = {
          ...defaultData,
          datasets: defaultData.datasets.map((oneData: any) => ({
            ...oneData,
            borderColor: color,
            borderWidth: 3,
            lineTension: 0.2,
            backgroundColor: type === "line" ? "transparent" : color,
            pointHoverRadius: 4,
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderWidth: 3,
            borderRadius: 5,
            barPercentage: 0.6,
            maxBarThickness: 25,
          })),
        };
        return { ...chartData };
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  return (
    <Paper
      sx={{
        height: 388,
        gridColumn: "span 3",
        p: 3,
        display: "flex",
        flexDirection: "column",
        borderRadius: "12px",
        boxShadow: "0 0 10px #1c295a14",
        ...sx,
      }}
    >
      <Box mb={3} display="flex" justifyContent="space-between">
        <Typography variant="h6">{title}</Typography>
        <RangePicker range={range} setRange={setRange} />
      </Box>
      <Box
        sx={{
          flexGrow: 1,
          width: 1,
          minHeight: 0,
        }}
      >
        {type !== "doughnut" ? (
          <Chart
            data={typeData}
            options={{
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  scaleLabel: {
                    display: true,
                    labelString: "Y text",
                  },
                },
                yAxis: {
                  title: {
                    // display: true,
                    display: false,
                    text: "Users (%)",
                    padding: {
                      top: 0,
                      bottom: 8,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  suggestedMin: 15,
                  suggestedMax: 85,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  scaleLabel: {
                    display: true,
                    labelString: "Y text",
                  },
                },
              },
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  // enabled:false,
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
                datalabels: {
                  display: type === "bar",
                  anchor: "end",
                  align: "top",
                  formatter: Math.round,
                  font: {
                    weight: "bold",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
            }}
          />
        ) : (
          <Box
            sx={{
              width: 1,
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              justifyItems: "center",
            }}
          >
            <Box width={190} alignSelf="center" position="relative">
              <Chart
                style={{ position: "relative", zIndex: 2 }}
                data={typeData}
                options={{
                  plugins: {
                    legend: {
                      display: false,
                    },
                    tooltip: {
                      displayColors: false,
                    },
                  },
                }}
              />
              <Box
                sx={{
                  zIndex: 1,
                  position: "absolute",
                  top: 70,
                  right: 0,
                  left: 0,
                  mx: "auto",
                  pointerEvents: "none",
                  textAlign: "center",
                }}
              >
                <Typography fontSize={28} fontWeight={700} lineHeight="1.2em">
                  {13}
                </Typography>
                <Typography
                  sx={{
                    textTransform: "uppercase",
                    fontSize: 14,
                    fontFamily: "Poppins !important",
                  }}
                >
                  Total Chargers
                </Typography>
              </Box>
            </Box>
            <Box mt={3} ml={3}>
              {[
                {
                  label: "Assigned Vendors",
                  value: 3,
                  color: theme.customColors.text.greenSecondary,
                },
                {
                  label: "Not Assigned",
                  value: 10,
                  color: theme.customColors.text.blueSecondary,
                },
              ].map(({ label, value, color }, i) => (
                <Box
                  key={i}
                  sx={{
                    position: "relative",
                    display: "flex",
                    flexDirection: "column",
                    // width: 1,
                    pl: 2.75,
                    mb: 2.5,
                    "& .value": {
                      mb: 1,
                      lineHeight: "1.2em",
                      fontSize: 20,
                      fontWeight: 700,
                      color: color,
                      "&:before": {
                        content: '""',
                        position: "absolute",
                        top: 4,
                        left: 0,
                        width: 14,
                        height: 14,
                        bgcolor: color,
                        borderRadius: "2px",
                      },
                    },
                    "& .title": {
                      color: "text.secondary",
                      fontSize: 14,
                      lineHeight: "1.4em",
                    },
                  }}
                >
                  <span className="value">{value}</span>
                  <span className="title">{label}</span>
                </Box>
              ))}
            </Box>
          </Box>
        )}
      </Box>
    </Paper>
  );
};

// {
//   responsive: true,
//   maintainAspectRatio: false,
//   cutoutPercentage: 80,
//   tooltip: { enabled: false },
//   centerText: {
//     display: true,
//     text: `90%`,
//   },
// }

export default ChartCard;
