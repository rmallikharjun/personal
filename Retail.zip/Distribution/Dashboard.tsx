import {
  BoltOutlined,
  PersonAddAlt1Outlined,
  HowToRegRounded,
  TuneOutlined,
  EditOutlined,
  DeleteOutline,
  CancelOutlined,
} from "@mui/icons-material";

import { useState, Fragment, useEffect } from "react";
import { Box, Button, IconButton, Paper, Tab, Tabs } from "@mui/material";
import Search from "components/Search";
import ChartCard from "./ChartCard";
import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";
import moment from "moment";
import ViewSelector, { View } from "components/ViewSelector";
import ListView from "./List";
import { BookDemo, SellVehicles } from "./PanelContents";
import BookmarkBorderOutlinedIcon from "@mui/icons-material/BookmarkBorderOutlined";
import PersonAddAltOutlinedIcon from "@mui/icons-material/PersonAddAltOutlined";
import AssignDistributor from "./AssignDistributor";
import { drawer, GlobalState } from "utils";
import { useSelector } from "react-redux";

const infoTabData = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];

const vendorsData = {
  data: [
    // {
    //   id: 1,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
    // {
    //   id: 2,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
    // {
    //   id: 3,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Unassigned",
    //   distributor: "-",
    // },
    // {
    //   id: 4,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
    // {
    //   id: 5,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
    // {
    //   id: 6,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Unassigned",
    //   distributor: "-",
    // },
    // {
    //   id: 7,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
    // {
    //   id: 8,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Unassigned",
    //   distributor: "-",
    // },
    // {
    //   id: 9,
    //   name: "Test Name",
    //   model: "-",
    //   assignedBy: moment().utc(),
    //   status: "Assigned",
    //   distributor: "-",
    // },
  ],
};

const elevationShadow =
  "rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px";
// const activeButton = {
//   color: "#fff",
//   background: "#3CB99E",
// };

const DistributionInfo: React.FC<any> = (props) => {
  const [activeTab, setActiveTab] = useState<string>("sell");
  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          p: 1,
          background: "#03241d",
        }}
      >
        <Box sx={{ fontWeight: "bold", fontSize: 14, color: "#f6f8fb" }}>
          Revos Test Encription
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
          >
            <EditOutlined />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
          >
            <DeleteOutline />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => drawer.close()}
          >
            <CancelOutlined />
          </IconButton>
        </Box>
      </Box>
      <Box p={2}>
        <Box
          sx={{
            background: "#f6f8fb",
            borderRadius: "6px",
            p: 1,
            fontSize: "14px",
            fontWeight: "bold",
          }}
        >
          Basic Info
        </Box>
        <Box
          sx={{
            width: "100%",
            p: 1,
          }}
        >
          {infoTabData.slice(0, 5).map((infoData: any, index: number) => (
            <Box
              key={index}
              sx={{ display: "flex", justifyContent: "space-between" }}
              mt={1}
              mb={1}
            >
              <Box
                component="span"
                sx={{ fontSize: 14, width: "50%", fontWeight: "bold" }}
              >
                Test
              </Box>
              <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                Result
              </Box>
            </Box>
          ))}
        </Box>
        <Box mt={1.5}>
          <Tabs
            value={activeTab}
            onChange={(_, val) => setActiveTab(val)}
            centered
          >
            <Tab value="sell" sx={{ width: "50%" }} label="Sell Vehicles" />
            <Tab value="book" sx={{ width: "50%" }} label="Book Demo" />
          </Tabs>
          {activeTab === "sell" && <SellVehicles />}
          {activeTab === "book" && <BookDemo />}
        </Box>
      </Box>
    </>
  );
};

const Distribution = () => {
  const [activeGridType, setActiveGridType] = useState<string>("grid");
  // eslint-disable-next-line
  const [tab, setTab] = useState("all");
  // eslint-disable-next-line
  const [activeCard, setActiveCard] = useState<number | null>(null);
  // const [activeTab, setActiveTab] = useState<string>("sell");
  const [showSelectedOptions, setShowSeletcedOptions] = useState<number | null>(
    null
  );
  const [showDialog, setShowDialog] = useState<boolean>(false);

  const {
    // user,
    // activeSection,
    drawer: rightDrawerPanel,
  } = useSelector((state: GlobalState) => state.global);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        position: "relative",
        overflow: "auto",
        height: "calc(100vh - 68px)",
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "column", flex: 1 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "56px",
            p: 3,
            mt: 4,
          }}
        >
          <Box sx={{ fontSize: 18, fontWeight: "bold", mt: 1.5 }}>
            Distributor
          </Box>
          <Box sx={{ display: "flex" }}>
            <ViewSelector
              extras={() => (
                <>
                  <Search
                    enableBorder
                    sx={{
                      width: 300,
                      p: 1,
                      pl: 1.5,
                      mr: 1.5,
                    }}
                    handleSearch={() => {}}
                  />
                </>
              )}
              view={activeGridType as View}
              setView={(type: View) => {
                if (type === "grid") {
                  drawer.close();
                }
                setActiveGridType(type);
              }}
            />
          </Box>
        </Box>
        {activeGridType === "grid" ? (
          <Fragment>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                p: 3,
                // overflow: "auto",
                // height: "calc(100vh - 168px)",
              }}
            >
              <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                <ChartCard
                  type="bar"
                  title="Vehicle Models"
                  color="#ffcd4f"
                  sx={{ width: "60%", mr: 3 }}
                />
                <ChartCard
                  type="doughnut"
                  title="Vehicle Models"
                  color="#ffcd4f"
                  sx={{ width: "40%" }}
                />
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <ChartCard
                  type="line"
                  title="Sold Vehicle Insights"
                  color="#8acdff"
                  sx={{ width: "60%", mr: 3 }}
                />
                <Paper
                  sx={{
                    height: 388,
                    gridColumn: "span 3",
                    p: 3,
                    display: "flex",
                    flexDirection: "column",
                    width: "40%",
                    borderRadius: "12px",
                  }}
                >
                  <Box sx={{ fontWeight: 700 }}>Distributors Summary</Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-evenly",
                      alignItems: "strech",
                      height: "100%",
                    }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        height: "100%",
                        alignItems: "center",
                      }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: "14px",
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <DirectionsCarIcon
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            100
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Total Distributors</Box>
                        </Box>
                      </Paper>
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          border: "0.3px solid #e3e3e3",
                          mr: 1,
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <PersonAddAlt1Outlined
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            100
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Total SubDistributors</Box>
                        </Box>
                      </Paper>
                    </Box>
                    <Box sx={{ fontWeight: 700, mt: 7 }}>Status Summary</Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        height: "100%",
                        alignItems: "center",
                      }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: "14px",
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <HowToRegRounded
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            100
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Assigned Distributors</Box>
                        </Box>
                      </Paper>
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: 1,
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <BoltOutlined
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            100
                          </Box>
                          <Box sx={{ fontSize: 13 }}>
                            UnAssigned Distributors
                          </Box>
                        </Box>
                      </Paper>
                    </Box>
                  </Box>
                </Paper>
              </Box>
            </Box>
          </Fragment>
        ) : (
          <Box sx={{ ml: 3, mt: 2, mr: activeCard !== null ? 0 : 3 }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                height: "5px",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                  p: 3,
                }}
              >
                <Box>
                  {showSelectedOptions &&
                    tab === "unassigned" &&
                    activeCard === null && (
                      <>
                        <Button
                          sx={{
                            color: "#000",
                          }}
                          variant="text"
                          startIcon={<PersonAddAltOutlinedIcon />}
                          onClick={() => setShowDialog(true)}
                        >
                          Assign Distributor
                        </Button>
                        <Button
                          sx={{
                            color: "#000",
                          }}
                          variant="text"
                          startIcon={<BookmarkBorderOutlinedIcon />}
                        >
                          Mark As Rental
                        </Button>
                      </>
                    )}
                </Box>
                <Button
                  sx={{
                    borderRadius: "4px",
                    boxShadow: elevationShadow,
                    color: "#000",
                    background: "#f6f8fb",
                    border: "none",
                    mt: 10,
                    "&:hover": {
                      border: "1px solid #000",
                    },
                  }}
                  variant="outlined"
                  startIcon={<TuneOutlined />}
                >
                  Filter By
                </Button>
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: rightDrawerPanel.open ? "calc(100vw - 678px)" : "100%",
              }}
            >
              <ListView
                vendors={{ vendorsData }}
                onViewClick={(index: number) => {
                  console.log(index);
                  // setActiveCard(index);
                  drawer.open(
                    <DistributionInfo data={vendorsData.data[index]} />
                  );
                }}
                onSelectionChange={(rows: any) =>
                  setShowSeletcedOptions(
                    rows && rows.length ? rows.length : null
                  )
                }
              />
            </Box>
          </Box>
        )}
      </Box>

      {/* <AssignDistributor
        open={showDialog}
        handleClose={() => setShowDialog(false)}
      /> */}
    </Box>
  );
};

export default Distribution;
