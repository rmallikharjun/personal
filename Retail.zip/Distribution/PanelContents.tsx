import { Box } from "@mui/system";
import React from "react";
import { useState } from "react";
import {
  Button,
  TextField,
  DialogContent,
  Stepper,
  Step,
  FormControlLabel,
  Checkbox,
  Radio,
  RadioGroup,
  FormControl,
  StepButton,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
export const SellVehicles: React.FC<any> = ({
  open = false,
  handleClose = () => {},
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const steps = ["User info", "Vehicle warranty", "Invoice"];
  const isLastStep = activeStep === steps.length - 1;
  return (
    <Box sx={{ width: "100%", mt: 1.5 }}>
      {/* export default function HorizontalLabelPositionBelowStepper() { */}
      <DialogContent>
        <Stepper activeStep={activeStep} alternativeLabel nonLinear>
          {steps.map((label: string, i) => (
            <Step key={i}>
              <StepButton onClick={() => setActiveStep(i)}>{label}</StepButton>
              {/* <StepLabel>{label}</StepLabel> */}
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <Box>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
                overflow: "auto",
                height: "25vh",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                First Name
                <TextField
                  margin="dense"
                  id="fname"
                  label="First Name"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                Last Name
                <TextField
                  margin="dense"
                  id="lname"
                  label="Last Name"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Parent Name
                <TextField
                  margin="dense"
                  id="parent"
                  label="Parent Name"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Phone no
                <TextField
                  margin="dense"
                  id="mobilenum"
                  label="Phone no"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Email Id
                <TextField
                  margin="dense"
                  id="email"
                  label="Email Id"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Adhaar card
                <TextField
                  margin="dense"
                  id="adhaar"
                  label="Adhaar card"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Address
                <TextField
                  margin="dense"
                  id="loc"
                  label="Address"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                DOB
                <TextField
                  margin="dense"
                  id="dt"
                  label="DOB"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
            </Box>
          </Box>
        )}
        {activeStep === 1 && (
          <Box>
            <Box
              sx={{ display: "flex", flexDirection: "row", flexWrap: "wrap" }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 3,
                  // width: "48%",
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                Warranty
                <TextField
                  margin="dense"
                  id="warranty"
                  label="Warranty"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 3,
                  // width: "48%",
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                Valid Through
                <TextField
                  margin="dense"
                  id="validity"
                  label="Date"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                />
              </Box>
            </Box>
            <FormControlLabel
              sx={{ fontWeight: 500 }}
              control={<Checkbox checked={false} size="small" />}
              label="Extended Warranty"
            />
          </Box>
        )}
        {activeStep === 2 && (
          <Box>
            <Box sx={{ fontWeight: 600, mt: 2, fontSize: 15 }}>
              Choose pricing type from below options
            </Box>
            <FormControl>
              <RadioGroup
                row
                aria-labelledby="row-radio-buttons-group-label"
                name="row-radio-buttons-group"
              >
                <FormControlLabel
                  value="One Time"
                  control={<Radio size="small" />}
                  label="One Time"
                />
                <FormControlLabel
                  value="emi"
                  control={<Radio size="small" />}
                  label="EMI"
                />
              </RadioGroup>
            </FormControl>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                mt: 1,
                mr: 1,
                lineHeight: 0.5,
                fontWeight: 500,
              }}
            >
              Total Amount
              <TextField
                margin="dense"
                id="amt"
                label="Total Amount"
                variant="outlined"
                sx={{ width: "50%" }}
                size="small"
              />
            </Box>
            <Button
              variant="contained"
              sx={{
                mt: 1,
                mr: 2,
                width: "35%",
                height: 30,
                fontSize: 12,
                justifyContent: "space-evenly",
              }}
              size="small"
            >
              <AddIcon />
              Add Warranty
            </Button>
          </Box>
        )}
      </DialogContent>

      {/* <Button variant="contained" sx={{mt:2,width:"25%"}}>Next</Button> */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
        {activeStep !== 0 && (
          <Button
            variant="outlined"
            onClick={() => {
              if (activeStep === 0) {
                handleClose();
              } else {
                setActiveStep(activeStep - 1);
              }
            }}
            sx={{ mt: "10%", mr: 2, width: "30%", height: "40%" }}
          >
            {activeStep === 0 ? "Cancel" : "Previous"}
          </Button>
        )}

        <Button
          variant="contained"
          onClick={() => {
            if (isLastStep) {
              handleClose();
              setActiveStep(0);
            } else {
              setActiveStep(activeStep + 1);
            }
          }}
          sx={{ mt: "10%", width: "30%", height: "40%" }}
        >
          {isLastStep ? "Save" : "Next"}
        </Button>
      </Box>
    </Box>
  );
};

export const BookDemo: React.FC<any> = (props) => {
  return (
    <Box>
      <Box sx={{ fontWeight: 600 }}>Fill the below details to book demo</Box>
      <Box sx={{ display: "flex", flexDirection: "row", flexWrap: "wrap" }}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          First Name
          <TextField
            margin="dense"
            id="name"
            label="First Name"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          Last Name
          <TextField
            margin="dense"
            id="name"
            label="Last Name"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          Email ID
          <TextField
            margin="dense"
            id="mailid"
            label="Email ID"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          Phone no
          <TextField
            margin="dense"
            id="phno"
            label="Phone no"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          Address
          <TextField
            margin="dense"
            id="address"
            label="Address"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 1,
            // width: "48%",
            flexGrow: 1,
          }}
        >
          DOB
          <TextField
            margin="dense"
            id="dob"
            label="DOB"
            variant="outlined"
            sx={{ width: "100%" }}
            size="small"
          />
        </Box>
        <Box>
          <Button>Book Demo</Button>
          <Button>Cancel</Button>
        </Box>
      </Box>
    </Box>
  );
};
