import {
  CancelOutlined,
  DeleteOutline,
  EditOutlined,
} from "@mui/icons-material";
import { Box, IconButton, Tab, Tabs } from "@mui/material";
import React, { useState } from "react";
import img from "../../../assets/images/revoslogo.png";
import { drawer, getDuration, setLoader, snackbar } from "utils";

const infoTabData = [
  { label: "Controller", value: "Controller" },
  { label: "Battery", value: "Controller" },
  { label: "Speedometer", value: "Controller" },
  { label: "Tyre", value: "Controller" },
  { label: "Motor", value: "Controller" },
  { label: "Chassis", value: "Controller" },
  { label: "Dc- Dc Converter", value: "Controller" },
  { label: "Lights", value: "Controller" },
  { label: "Switches", value: "Controller" },
];
const configTabData = [
  { label: "Access Type", value: "Access Type" },
  { label: "Wheel Diameter", value: "Wheel Diameter" },
  { label: "Max Speed", value: "Max Speed" },
  { label: "Pickup Control Limit", value: "Pickup Control Limit" },
  { label: "Zero Throttle Limit", value: "Zero Throttle Limit" },
  { label: "Current Limit", value: "Current Limit" },
  {
    label: "Controller Over Voltage Limit",
    value: "Controller Over Voltage Limit",
  },
  {
    label: "Controller Under Voltage Limit",
    value: "Controller Under Voltage Limit",
  },
  { label: "Hill Assist", value: "Hill Assist" },
];

const AssemblyInfo: React.FC<any> = (props) => {
  const { activeGridType, setActiveCard, data } = props;
  const [activeTab, setActiveTab] = useState<string>("info");
  // console.log('data ==> ', data);
  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          p: 1,
          background: "#03241d",
        }}
      >
        <Box sx={{ fontWeight: "bold", fontSize: 14, color: "#f6f8fb" }}>
          {data.name || "Revos Test Encription"}
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
          >
            <EditOutlined />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
          >
            <DeleteOutline />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => {
              setActiveCard(null);
              drawer.close();
            }}
          >
            <CancelOutlined />
          </IconButton>
        </Box>
      </Box>
      <Box p={2}>
        <Box
          sx={{
            background: "#f6f8fb",
            borderRadius: "6px",
            p: 1,
            fontSize: "14px",
            fontWeight: "bold",
          }}
        >
          Basic Info
        </Box>
        <Box mt={2} sx={{ display: "flex", flexDirection: "row", height: 150 }}>
          {activeGridType === "grid" && (
            <Box
              sx={{
                width: "160px",
                background: `url(${img}) no-repeat`,
                backgroundSize: "cover",
                backgroundPositionY: "50%",
                borderRadius: "8px",
              }}
              mr={2}
            />
          )}
          <Box
            sx={{
              width: activeGridType === "grid" ? "calc(100% - 160px)" : "100%",
              p: 1,
            }}
          >
            {infoTabData.slice(0, 3).map((infoData: any, index: number) => (
              <Box
                key={index}
                sx={{ display: "flex", justifyContent: "space-between" }}
                mt={1}
                mb={1}
              >
                <Box
                  component="span"
                  sx={{ fontSize: 14, width: "50%", fontWeight: "bold" }}
                >
                  {infoData.label || "Test"}
                </Box>
                <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                  {infoData.value || "Result"}
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
        {activeGridType === "grid" && (
          <Box mt={3}>
            <Tabs
              value={activeTab}
              onChange={(_, val) => setActiveTab(val)}
              centered
            >
              <Tab
                value="info"
                sx={{ width: "50%" }}
                label="Product Information"
              />
              <Tab value="config" sx={{ width: "50%" }} label="Configuration" />
            </Tabs>
            {activeTab === "info" && (
              <Box p={2.5}>
                {infoTabData.map((infoData: any, index: number) => (
                  <Box
                    key={index}
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                    }}
                    mt={1}
                    mb={1}
                  >
                    <Box
                      component="span"
                      sx={{
                        fontSize: 14,
                        width: "50%",
                        fontWeight: "bold",
                      }}
                    >
                      {infoData.label || "Test"}
                    </Box>
                    <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                      {infoData.value || "Result"}
                    </Box>
                  </Box>
                ))}
              </Box>
            )}
            {activeTab === "config" && (
              <Box p={2.5}>
                {configTabData.map((infoData: any, index: number) => (
                  <Box
                    key={index}
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                    }}
                    mt={1}
                    mb={1}
                  >
                    <Box
                      component="span"
                      sx={{
                        fontSize: 14,
                        width: "50%",
                        fontWeight: "bold",
                      }}
                    >
                      {infoData.label || "Test"}
                    </Box>
                    <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                      {infoData.value || "Result"}
                    </Box>
                  </Box>
                ))}
              </Box>
            )}
          </Box>
        )}
      </Box>
    </>
  );
};

export default AssemblyInfo;
