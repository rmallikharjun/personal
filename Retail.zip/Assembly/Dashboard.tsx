import { Fragment, useState, useEffect } from "react";
import { Add, TuneOutlined } from "@mui/icons-material";
import { Box, Button, FormControlLabel, Checkbox, Grid } from "@mui/material";
import { drawer } from "utils";
import Search from "components/Search";
import ViewSelector, { View } from "components/ViewSelector";
import ListView from "./List";
import { AddVehicle, CreateModel } from "./Models";
import moment from "moment";
import AssemblyCard from "./AssemblyCard";
import AssemblyInfo from "./AssemblyInfo";
import { useQuery } from "react-query";
import { getPermissions, authorizedFetch } from "utils";
import { BOLT_URL } from "utils/constants";

const vendorsData = {
  data: [
    {
      id: 1,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 2,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 3,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 4,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 5,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 6,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 7,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 8,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
    {
      id: 9,
      name: "Test Name",
      model: "Test Model",
      createdAt: moment().utc(),
    },
  ],
};

const testData = [{}, {}, {}, {}, {}, {}];

const elevationShadow =
  "rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px";
const activeButton = {
  color: "#fff",
  background: "#3CB99E",
};

interface AssemblyProps {}

const Assembly: React.FC<AssemblyProps> = (props) => {
  const [activeCard, setActiveCard] = useState<number | null>(null);
  const [activeGridType, setActiveGridType] = useState<string>("grid");
  const [showDialog, setShowDialog] = useState<null | string>(null);
  const [showSelectedOptions, setShowSeletcedOptions] = useState<number | null>(
    null
  );

  const [search, setSearch] = useState("");

  const [selectedCity, setSelectedCity] = useState<any>("");

  const modelsUrl = `${BOLT_URL}/company/getVendors?orderBy=CREATED_AT_DESC&${
    !search ? `city=${selectedCity}` : `search=${search}`
  }`;

  const { isLoading: vendorsLoading, data: vendorsData } = useQuery(
    ["getVendors", selectedCity],
    () => authorizedFetch(modelsUrl)
  );

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        position: "relative",
      }}
    >
      <Box
        sx={{
          // p: 3,
          display: "flex",
          flexDirection: "column",
          width: "100%",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "56px",
            p: 3,
            mt: 4,
          }}
        >
          <Box sx={{ fontSize: 18, fontWeight: "bold", mt: 1.5 }}>Models</Box>
          <Box sx={{ display: "flex" }}>
            <ViewSelector
              extras={() => (
                <>
                  <Search
                    enableBorder
                    sx={{
                      width: 300,
                      p: 1,
                      pl: 1.5,
                      mr: 1.5,
                    }}
                    handleSearch={() => {}}
                  />
                  <Button
                    sx={{ mr: { xs: 1, md: 2 } }}
                    onClick={() => setShowDialog("create")}
                  >
                    <Add />
                  </Button>
                </>
              )}
              view={activeGridType as View}
              setView={(type: View) => {
                drawer.close();
                setActiveCard(null);
                setActiveGridType(type);
              }}
            />
          </Box>
        </Box>
        {activeGridType === "grid" ? (
          <Fragment>
            <Box
              sx={{
                // mt: 4,
                p: 3,
                display: "flex",
                justifyContent: "flex-start",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  fontSize: 14,
                }}
              >
                <Box sx={{ mr: 2, display: "flex", alignItems: "center" }}>
                  <TuneOutlined style={{ marginRight: "10px" }} />
                  Protocol Filters:
                </Box>
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Bluetooth"
                />
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Sim"
                />
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Speedometer"
                />
              </Box>
            </Box>
            <Grid
              container
              spacing={2}
              columns={{ xs: 2, sm: 6, md: 6, lg: 12 }}
              sx={{
                pb: 2,
                pr: 3,
                pl: 3,
                maxHeight: "70vh",
                overflow: "auto",
              }}
            >
              {vendorsData?.data?.map((data: any, index: number) => (
                <AssemblyCard
                  data={data}
                  activeCard={activeCard}
                  index={index}
                  gridType={activeGridType}
                  setActiveCard={setActiveCard}
                  showDialog={setShowDialog}
                />
              ))}
            </Grid>
          </Fragment>
        ) : (
          <Fragment>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ListView
                vendors={vendorsData}
                onViewClick={(rowData: any) => {
                  drawer.open(
                    <AssemblyInfo
                      activeGridType={activeGridType}
                      setActiveCard={setActiveCard}
                      data={rowData}
                    />
                  );
                }}
                onSelectionChange={(rows: any) =>
                  setShowSeletcedOptions(
                    rows && rows.length ? rows.length : null
                  )
                }
              />
            </Box>
          </Fragment>
        )}
      </Box>
      <AddVehicle
        open={showDialog === "add"}
        handleClose={() => setShowDialog(null)}
      />
      <CreateModel
        open={showDialog === "create"}
        handleClose={() => setShowDialog(null)}
      />
    </Box>
  );
};

export default Assembly;
