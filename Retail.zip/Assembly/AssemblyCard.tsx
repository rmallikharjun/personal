import { Box, Button, Grid, Card } from "@mui/material";
import React from "react";
import { drawer, getDuration, setLoader, snackbar } from "utils";
import img from "../../../assets/images/revoslogo.png";
import AssemblyInfo from "./AssemblyInfo";

import CustmChip from "./CustomChip";

interface AssemblyCardProps {
  data: any;
  activeCard: null | number;
  setActiveCard: (val: null | number) => void;
  gridType: string;
  showDialog: (val: string) => void;
  index: number;
}

const AssemblyCard: React.FC<AssemblyCardProps> = ({
  data,
  activeCard,
  index,
  setActiveCard,
  gridType,
  showDialog,
}) => {
  const activeCardStyles =
    activeCard === index
      ? {
          border: "2px solid #3CB99E",
        }
      : {};
  return (
    <Grid
      key={index}
      xs={2}
      sm={3}
      md={3}
      lg={activeCard !== null ? 6 : 4}
      item
      sx={{
        height: 310,
      }}
      onClick={(e: any) => {
        e.preventDefault();
        const activeVal = index === activeCard ? null : index;
        setActiveCard(activeVal);
        if (activeVal === null) {
          drawer.close();
        } else {
          drawer.open(
            <AssemblyInfo
              activeGridType={gridType}
              setActiveCard={setActiveCard}
              data={{ ...data }}
            />
          );
        }
      }}
    >
      <Card
        sx={{
          p: 1,
          borderRadius: "12px",
          cursor: "pointer",
          "&:hover": {
            border: "1px solid #3CB99E",
            // p:1
          },
          height: "100%",
          ...activeCardStyles,
        }}
      >
        <Box
          sx={{
            pb: 1,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box sx={{ fontWeight: "bold", fontSize: 16 }}>
            {data.name || "Revos Test Encription"}
          </Box>
          <CustmChip label="Instock- 5 Left" />
        </Box>
        <Box sx={{ width: "100%" }}>
          <Box
            sx={{
              height: 137,
              background: `url(${img}) no-repeat`,
              backgroundSize: "cover",
              backgroundPositionY: "50%",
              borderRadius: "8px",
            }}
          />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row", mt: 1.5 }}>
          <CustmChip label="Bluetooth" sx={{ mr: 1.5 }} />
          <CustmChip label="Sim" sx={{ mr: 1.5 }} />
          <CustmChip label="Speedometer" />
        </Box>
        <Box
          sx={{
            mt: 2,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Button
            variant="outlined"
            fullWidth
            onClick={() => {}}
            sx={{ mr: 1, fontSize: 12 }}
          >
            VIEW INVENTORY
          </Button>
          <Button
            variant="contained"
            fullWidth
            onClick={(e: any) => {
              showDialog("add");
              e.preventDefault();
              e.stopPropagation();
            }}
            sx={{ fontSize: 12 }}
          >
            ASSEMBLE
          </Button>
        </Box>
      </Card>
    </Grid>
  );
};

export default AssemblyCard;
