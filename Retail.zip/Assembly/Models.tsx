import { useState, Fragment } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  MenuItem,
  Divider,
  Stepper,
  Step,
  IconButton,
  StepButton,
  Typography,
} from "@mui/material";
import { useDropzone } from "react-dropzone";
import {
  AddPhotoAlternateOutlined,
  Delete,
  QrCodeScanner,
  HighlightOff,
} from "@mui/icons-material";

const colorOptions: Array<{ label: string; value: string }> = [];

export const AddVehicle: React.FC<any> = ({
  open = false,
  handleClose = () => {},
}) => {
  const [addOthers, setAddOthers] = useState<boolean>(false);
  return (
    <Dialog
      PaperProps={{
        sx: {
          width: "48vw",
          maxWidth: "60vw",
          position: "relative",
          padding: "10",
        },
      }}
      open={open}
      onClose={handleClose}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add Vehicle
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent
        sx={{ display: "flex", flexDirection: "column", overflow: "hidden" }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mt: 2,
            mr: 2,
            width: "100%",
          }}
        >
          Model Name{" "}
        </Box>
        <TextField
          margin="dense"
          id="name"
          label="Revos Test Inscription"
          variant="outlined"
          sx={{ width: "50%" }}
          size="small"
        />
        <Box sx={{ mt: 3, ml: 0.4, fontWeight: 600 }}> Other Information</Box>

        <Box sx={{ display: "flex", flexDirection: "row", mt: 5 }}>
          <Box
            sx={{
              width: "50%",
              height: "100px",
              background: "rgba(104, 214, 165, 0.3)",
              borderRadius: "8px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              mr: 2,
              position: "relative",
            }}
          >
            <Box
              sx={{ position: "absolute", top: -24, left: 5, fontWeight: 500 }}
            >
              Front Tyre
            </Box>
            <QrCodeScanner
              style={{ color: "#3CB99E", fontSize: 32, marginRight: 2 }}
            />
            Scan Code
          </Box>
          <Box
            sx={{
              width: "50%",
              height: "100px",
              background: "rgba(104, 214, 165, 0.3)",
              borderRadius: "8px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              position: "relative",
            }}
          >
            <Box
              sx={{ position: "absolute", top: -24, left: 5, fontWeight: 500 }}
            >
              Rear Tyre
            </Box>
            <QrCodeScanner
              style={{ color: "#3CB99E", fontSize: 32, marginRight: 2 }}
            />
            Scan Code
          </Box>
        </Box>
        <TextField
          margin="dense"
          id="color"
          label="Choose Color"
          variant="outlined"
          select
          sx={{ width: "50%", mt: 2 }}
          size="small"
        >
          {colorOptions.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        {!addOthers ? (
          <Button
            variant="text"
            sx={{ width: 166, mt: 2 }}
            onClick={() => setAddOthers(true)}
          >
            + Add Other Items
          </Button>
        ) : (
          <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Box>Add Other Items</Box>
              <Box>
                <Button
                  onClick={() => setAddOthers(false)}
                  variant="text"
                  startIcon={<Delete />}
                  sx={{ color: "#5A607F" }}
                >
                  Remove
                </Button>
              </Box>
            </Box>
            <Divider sx={{ mb: 2, mt: 2 }} />
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <TextField
                margin="dense"
                id="key"
                label="Key"
                variant="outlined"
                size="small"
                sx={{ mr: 2 }}
              />
              <TextField
                margin="dense"
                id="value"
                label="Value"
                variant="outlined"
                size="small"
              />
            </Box>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" color="primary" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" color="primary" onClick={handleClose}>
          Save
        </Button>
      </DialogActions>

      {/* <CancelOutlined
        onClick={handleClose}
        style={{
          position: "absolute",
          top: 12,
          right: 12,
          fontSize: 22,
          cursor: "pointer",
        }}
      /> */}
    </Dialog>
  );
};
const vehicleOptions: Array<{ label: string; value: string }> = [];
const protocolOptions: Array<{ label: string; value: string }> = [];
// const controllerOptions: Array<{ label: string; value: string }> = [];
// const batteryOptions: Array<{ label: string; value: string }> = [];
// const speedometerOptions: Array<{ label: string; value: string }> = [];
// const tyreOptions: Array<{ label: string; value: string }> = [];
// const motorOptions: Array<{ label: string; value: string }> = [];
// const chassisOptions: Array<{ label: string; value: string }> = [];
// const dcDaConverterOptions: Array<{ label: string; value: string }> = [];
// const lightsOptions: Array<{ label: string; value: string }> = [];
// const switchesOptions: Array<{ label: string; value: string }> = [];

export const CreateModel: React.FC<any> = ({
  open = false,
  handleClose = () => {},
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const steps = ["Model Info.", "Components"];
  const isLastStep = activeStep === steps.length - 1;
  const [files, setFiles] = useState<File[]>([]);

  const { getRootProps, getInputProps } = useDropzone({
    // accept: 'image/*',
    onDrop: (newFiles) => {
      setFiles(newFiles);
    },
  });

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Create Model
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ mb: 4, mt: 2, mx: "auto", maxWidth: 534 }}
          activeStep={activeStep}
          alternativeLabel
          nonLinear
        >
          {steps.map((label: string, i) => (
            <Step key={i}>
              <StepButton onClick={() => setActiveStep(i)}>{label}</StepButton>
              {/* <StepLabel>{label}</StepLabel> */}
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <Box>
            {/* <Box>ModelInfo Components</Box> */}
            <Box>Model Info</Box>
            <Box
              sx={{
                mt: 2,
                mb: 2,
                border: "1px dashed #ccc",
                borderRadius: "8px",
                width: "100%",
                height: 80,
              }}
            >
              <Box sx={{ height: "100%", width: "100%" }} {...getRootProps()}>
                {files.length === 0 ? (
                  <>
                    <input {...getInputProps()} />
                    <Box
                      sx={{
                        fontSize: 14,
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        flexDirection: "column",
                        height: "100%",
                      }}
                    >
                      <AddPhotoAlternateOutlined sx={{ fontSize: 24, mb: 2 }} />
                      <Box>
                        <span style={{ color: "#3CB99E" }}>Upload a file</span>{" "}
                        or drag and drop
                      </Box>
                    </Box>
                  </>
                ) : (
                  <Box
                    sx={{
                      fontSize: 14,
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      flexDirection: "column",
                      height: "100%",
                    }}
                  >
                    <span style={{ color: "#3CB99E" }}>
                      {files.length > 1
                        ? `${files.length} files were uploaded`
                        : `${files.length} file is uploaded`}
                    </span>
                  </Box>
                )}
              </Box>
            </Box>
            <Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    width: "50%",
                    mr: 2,
                  }}
                >
                  <Typography className="label">Vehicle Model</Typography>

                  <TextField
                    margin="dense"
                    id="vehicle"
                    label="Enter Name"
                    variant="outlined"
                    size="small"
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    width: "50%",
                  }}
                >
                  <Typography className="label"> Model Id</Typography>

                  <TextField
                    margin="dense"
                    id="model"
                    label="Enter Id"
                    variant="outlined"
                    size="small"
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label"> Vehicle Type</Typography>

                  <TextField
                    margin="dense"
                    id="vehicle"
                    label="Vehicle Type"
                    variant="outlined"
                    select
                    sx={{ flexGrow: 1 }}
                    size="small"
                  >
                    {vehicleOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label"> Protocol</Typography>

                  <TextField
                    margin="dense"
                    id="Protocol"
                    label="Protocol Type"
                    variant="outlined"
                    select
                    sx={{ flexGrow: 1 }}
                    size="small"
                  >
                    {protocolOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Box>
              </Box>
            </Box>
          </Box>
        )}

        {activeStep === 1 && (
          <Box>
            <Box>Components</Box>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Controller
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Controller"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {vehicleOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Battery
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Battery"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {protocolOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Speedometer
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Speedometer"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {vehicleOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Tyre
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Tyre"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {protocolOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Motor
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Motor"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {vehicleOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Chassis
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Chassis"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {protocolOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                DC DA Converter
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="DC DA Converter"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {vehicleOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Lights
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Lights"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {protocolOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                Switches
                <TextField
                  margin="dense"
                  id="vehicle"
                  label="Switches"
                  variant="outlined"
                  select
                  sx={{ width: "100%", mt: 2 }}
                  size="small"
                >
                  {vehicleOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 2,
                  mr: 2,
                  width: "100%",
                }}
              >
                {" "}
              </Box>
            </Box>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          onClick={() => {
            if (activeStep === 0) {
              handleClose();
            } else {
              setActiveStep(activeStep - 1);
            }
          }}
        >
          {activeStep === 0 ? "Cancel" : "Previous"}
        </Button>
        <Button
          variant="contained"
          onClick={() => {
            if (isLastStep) {
              handleClose();
              setActiveStep(0);
            } else {
              setActiveStep(activeStep + 1);
            }
          }}
        >
          {isLastStep ? "Save" : "Next"}
        </Button>
      </DialogActions>

      {/* <CancelOutlined
        onClick={handleClose}
        style={{
          position: "absolute",
          top: 12,
          right: 12,
          fontSize: 22,
          cursor: "pointer",
        }}
      /> */}
    </Dialog>
  );
};
