import {
  Box,
  Button,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
} from "@mui/material";
import Table from "components/Table";
import moment from "moment";
import { useState } from "react";
import { getPermissions } from "utils";
import { DeleteOutline, InfoOutlined } from "@mui/icons-material";
import CloseIcon from "@mui/icons-material/Close";
import TuneIcon from "@mui/icons-material/Tune";
import { gql, useMutation } from "@apollo/client";
import { queryClient } from "index";
import { snackbar, setLoader } from "utils";

const List = ({
  vendors: vendorsData,
  onViewClick,
  isLoading: vendorsLoading,
}: any) => {
  const { canWrite } = getPermissions("charger:vendors");
  // const [tab, setTab] = useState(0);
  const [selectedRows, setSelectedRows] = useState([]);
  const [deleteDialog, setDeleteDialog] = useState<any>({
    open: false,
    selected: [],
  });

  console.log(selectedRows);

  const [dropdownEntries, setDropdownEntries] = useState([
    {
      type: "heading",
      label: "CITY",
      searchable: true,
    },
  ]);

  const getDropdownData = (entry: any[]) => {
    setDropdownEntries([
      {
        type: "heading",
        label: "CITY",
        searchable: true,
      },
      ...entry,
    ]);
  };

  const getChip = (label: string, styles: any = {}) => {
    return (
      <Box
        sx={{
          background: "rgba(104, 214, 165, 0.2)",
          padding: 1,
          fontSize: 10,
          color: "#3CB99E",
          height: 27,
          width: 75,
          display: "flex",
          alignItems: "Center",
          borderRadius: "4px",
          ...styles,
        }}
      >
        {label}
        <CloseIcon fontSize="inherit" sx={{ ml: 1 }} />
      </Box>
    );
  };

  return (
    <>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          mr: 3.5,
          ml: 3.3,
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            mt: 3,
            mb: 2,
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ display: "flex", flexDirection: "row", mt: 1.5 }}>
            {getChip("Parle", { ml: 3.5, fontWeight: 600, fontSize: 12 })}
            {getChip("Nestle", { ml: 2, fontWeight: 600, fontSize: 12 })}
          </Box>
          <Box sx={{ pr: 3 }}>
            <Button
              sx={{
                borderRadius: "4px",
                boxShadow: 1,
                color: "#000",
                background: "#f6f8fb",
                border: "none",
                width: "100%",
                "&:hover": {
                  border: "1px solid #000",
                },
              }}
              variant="outlined"
              startIcon={<TuneIcon />}
            >
              Filter By
            </Button>
          </Box>
        </Box>{" "}
        <Table
          loading={vendorsLoading}
          setSelectedRows={setSelectedRows}
          selectable={canWrite}
          rows={vendorsData?.data || []}
          columns={[
            {
              key: "VIN",
              label: "Vin",
              Render: (row) => <Box sx={{ py: 2 }}>{row.name}</Box>,
            },
            {
              key: "Model",
              label: "Model",
              Render: (row) => <Box>{row.model}</Box>,
            },
            {
              key: "DateReceived",
              label: "Date Received",
              Render: (row) => (
                <Box>{moment(row.createdAt).format("ddd, MMM DD, YYYY")}</Box>
              ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Button
                  variant="action"
                  onClick={() => {
                    onViewClick(row);
                  }}
                >
                  View
                </Button>
              ),
            },
          ]}
          toolbar={() => (
            <Button
              startIcon={<DeleteOutline />}
              onClick={() => {
                setDeleteDialog({ open: true, data: selectedRows });
              }}
            >
              Delete
            </Button>
          )}
        />
      </Paper>
      <DeleteDialog
        open={deleteDialog.open}
        handleClose={() => {
          setDeleteDialog({ ...deleteDialog, open: false });
        }}
        selected={deleteDialog.data}
      />
    </>
  );
};

interface DeleteVendorProps {
  open: boolean;
  handleClose: () => void;
  selected: string[];
}

const DeleteDialog: React.FC<DeleteVendorProps> = ({
  open,
  handleClose,
  selected,
}) => {
  const UPDATE_STATUS = gql`
    mutation DeleteSubCompany($where: CompanyDeleteInput!) {
      company {
        deleteSubCompany(where: $where) {
          id
          status
        }
      }
    }
  `;
  const [deleteVendor] = useMutation(UPDATE_STATUS, {
    onCompleted: () => {
      ["allStats", "getVendors"].forEach((query) => {
        queryClient.resetQueries(query, { exact: true });
      });
      setLoader(false);
      snackbar.success(`Vendor${selected?.length > 1 ? "s" : ""} deleted`);
      handleClose();
    },
    onError: () => {
      setLoader(false);
      snackbar.error(`Error deleting vendor${selected?.length > 1 ? "s" : ""}`);
    },
  });
  function confirm() {
    setLoader(true);
    deleteVendor({
      variables: {
        where: {
          id: selected,
        },
      },
    });
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Model{selected?.length > 1 ? "s" : ""}</DialogTitle>
      <DialogContent className="py-1">
        Delete {selected?.length > 1 || ""} selected vendor
        {selected?.length > 1 ? "s" : ""}?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default List;
